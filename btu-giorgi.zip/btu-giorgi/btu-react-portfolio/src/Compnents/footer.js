import React from "react";
import './footer.css'
function Footer(){
   return(
       <>
        <footer>
          <p>Creator George Jumushadze</p>
          <p>All right reserved</p>
        </footer>
       </>
   )
}

export default Footer