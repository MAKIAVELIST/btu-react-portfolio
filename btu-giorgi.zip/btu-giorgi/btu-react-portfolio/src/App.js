import Header from "./Compnents/Header/Header";
import Footer from "./Compnents/footer";
function App() {
  return (
    <div className="App">
      <Header/>
      <Footer/>
    </div>
  );
}

export default App;
